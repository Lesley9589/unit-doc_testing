#finding higest value

def max_number(list):
    '''
    >>> max_number([3, 5, 9, 12, 78])
    78
    '''
    return max(list)
print(max_number([3, 5, 9, 12, 78]))

# descending order

def descending_order(my_list):
    '''
    >>> descending_order([3, 5, 99, 9, 12, 78])
    [99, 78, 12, 9, 5, 3]
    '''

    my_list = [3, 5, 99, 9, 12, 78]
    x = sorted(my_list, reverse=True)
    return x
print(descending_order([3, 5, 99, 9, 12, 78]))
import unittest
from test1task import *

class Test1Task(unittest.TestCase):
#highest value
    def test_max_number(self):
        assert max_number([3, 5, 9, 12, 78]) == 78, "78 is the max number"

#descending order

    def test_descending_order(self):
        assert descending_order([3, 5, 99, 9, 12, 78]) == [99, 78, 12, 9, 5, 3], "[99, 78, 12, 9, 5, 3] list in descending order"